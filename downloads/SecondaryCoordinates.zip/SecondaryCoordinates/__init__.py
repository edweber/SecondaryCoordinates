from .SecondaryCoordinates import SecondaryCoordinates


def classFactory(iface):
    return SecondaryCoordinates(iface)
