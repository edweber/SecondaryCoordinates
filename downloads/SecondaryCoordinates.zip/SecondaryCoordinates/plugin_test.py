import SecondaryCoordinates


def l():
    plug = SecondaryCoordinates.SecondaryCoordinates(iface)
    plug.initGui()
    return(plug)


self = l()

# there is an ipyconsole plugin in qgis

# used the qgis-plugin-ci package to generate xml

# you need to just zip the thing and add to the repo to get the xml to work right
# b/c github appends things to its zips, e.g. "-main"
