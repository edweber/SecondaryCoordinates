import SecondaryCoordinates


def l():
    plug = SecondaryCoordinates.SecondaryCoordinates(iface)
    plug.initGui()
    return(plug)


self = l()


# access a loaded plugin to debug:
from qgis import utils


self = utils.plugins['SecondaryCoordinates']


# there is an ipyconsole plugin in qgis

# you need to just zip the thing and add to the repo to get the xml to work right
# b/c github appends things to its zips, e.g. "-main"
